import java.util.*;

public class Question1A {
    static class Edge {
        int to, cost, time;

        Edge(int to, int cost, int time) {
            this.to = to;
            this.cost = cost;
            this.time = time;
        }
    }

    static int n, m;
    static List<Edge>[] G;
    static int[] dist, cost;
    static boolean[] used;

    static int dijkstra(int s, int t, int limit) {
        Arrays.fill(dist, Integer.MAX_VALUE / 2);
        Arrays.fill(cost, Integer.MAX_VALUE / 2);
        Arrays.fill(used, false);

        PriorityQueue<Integer> pq = new PriorityQueue<>((u, v) -> dist[u] - dist[v]);
        dist[s] = 0;
        cost[s] = 0;
        pq.offer(s);

        while (!pq.isEmpty()) {
            int v = pq.poll();
            if (v == t) break;
            if (used[v]) continue;
            used[v] = true;

            for (Edge e : G[v]) {
                int u = e.to;
                int time = e.time;
                int c = e.cost;
                if (dist[v] + time > limit) continue;
                if (dist[u] > dist[v] + time) {
                    dist[u] = dist[v] + time;
                    cost[u] = cost[v] + c;
                    pq.offer(u);
                } else if (dist[u] == dist[v] + time && cost[u] > cost[v] + c) {
                    cost[u] = cost[v] + c;
                    pq.offer(u);
                }
            }
        }

        return cost[t];
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        n = sc.nextInt();
        m = sc.nextInt();
        G = new ArrayList[n];
        for (int i = 0; i < n; i++) G[i] = new ArrayList<>();
        for (int i = 0; i < m; i++) {
            int u = sc.nextInt(), v = sc.nextInt(), t = sc.nextInt(), c = sc.nextInt();
            G[u].add(new Edge(v, c, t));
            G[v].add(new Edge(u, c, t));
        }
        int s = sc.nextInt(), t = sc.nextInt(), limit = sc.nextInt();
        dist = new int[n];
        cost = new int[n];
        used = new boolean[n];

        System.out.println(dijkstra(s, t, limit));
    }
}

