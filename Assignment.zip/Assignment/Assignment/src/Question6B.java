import java.util.HashMap;

public class Question6B {
    static HashMap<Character, Integer> charToNum = new HashMap<>();
    static int[] wordToNum(String word) {
        int[] nums = new int[word.length()];
        for (int i = 1; i < word.length(); i++) {
            nums[i] = charToNum.get(word.charAt(i));
        }
        return nums;
    }
    static int toNum(int[] nums) {
        int num = 0;
        for (int i = 0; i < nums.length; i++) {
            num = num * 10 + nums[i];
        }
        return num;
    }
    public static boolean isValid(String[] words, String result) {
        charToNum.clear();
        int cnt = 0;
        for (String word : words) {
            for (char c : word.toCharArray()) {
                if (!charToNum.containsKey(c)) {
                    charToNum.put(c, cnt++);
                }
            }
        }
        int[] wordNums = wordToNum(result);
        int target = toNum(wordNums);
        int sum = 0;
        for (String word : words) {
            int[] nums = wordToNum(word);
            sum += toNum(nums);
        }
        return sum == target;
    }
    public static void main(String[] args) {
        String[] words = {"SIX", "SEVEN", "SEVEN"};
        String result = "TWENTY";
        System.out.println(isValid(words, result));
    }
}
