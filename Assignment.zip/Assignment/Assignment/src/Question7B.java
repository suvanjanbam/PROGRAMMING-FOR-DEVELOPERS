import java.util.ArrayList;

public class Question7B {
    public class WebCrawler implements Runnable{
        private static final int MAX_DEPTH=3;
        private Thread thread;
        private String first_link;
        private ArrayList<String> visitedLinks= new ArrayList<String>();
        private int ID;
        public WebCrawler(String link,int num){
            System.out.println("WebCrawler Created");
            first_link=link;
            ID=num;

            thread=new Thread(this);
            thread.start();

        }


        @Override
        public void run() {

        }

    }

}
