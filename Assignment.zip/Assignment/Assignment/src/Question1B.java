import java.util.*;

public class Question1B {
    static List<Integer>[] G;
    static boolean[] visited;

    static void dfs(int u) {
        visited[u] = true;
        for (int v : G[u]) {
            if (!visited[v]) dfs(v);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int m = sc.nextInt();
        G = new ArrayList[n];
        for (int i = 0; i < n; i++) G[i] = new ArrayList<>();
        for (int i = 0; i < m; i++) {
            int u = sc.nextInt(), v = sc.nextInt();
            G[u].add(v);
            G[v].add(u);
        }
        int k = sc.nextInt();
        visited = new boolean[n];
        dfs(0);
        List<Integer> res = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            if (visited[i] && !visited[k]) res.add(i);
        }
        System.out.println(res);
    }
}
