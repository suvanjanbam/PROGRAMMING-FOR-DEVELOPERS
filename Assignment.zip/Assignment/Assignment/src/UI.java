import javax.swing.*;

public class UI extends JFrame {
}
