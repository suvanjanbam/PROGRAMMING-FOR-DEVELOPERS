import java.util.HashMap;
import java.util.Map;

public class Question4A {
    class Node {
        int key;
        int value;
        int count;
        Node prev;
        Node next;

        public Node(int key, int value) {
            this.key = key;
            this.value = value;
            this.count = 1;
        }
    }

    int capacity;
    Map<Integer, Node> cache;
    Map<Integer, Node> head;
    Map<Integer, Node> tail;

    public Question4A(int capacity) {
        this.capacity = capacity;
        cache = new HashMap<>();
        head = new HashMap<>();
        tail = new HashMap<>();
    }

    public int get(int key) {
        if (!cache.containsKey(key)) {
            return -1;
        }

        Node node = cache.get(key);
        remove(node);
        add(node);

        return node.value;
    }

    public void put(int key, int value) {
        if (capacity == 0) {
            return;
        }

        if (cache.containsKey(key)) {
            Node node = cache.get(key);
            node.value = value;
            remove(node);
            add(node);
        } else {
            if (cache.size() == capacity) {
                cache.remove(head.get(head.size()).key);
                remove(head.get(head.size()));
            }
            Node node = new Node(key, value);
            cache.put(key, node);
            add(node);
        }
    }

    private void remove(Node node) {
        if (head.get(node.count) == node) {
            head.put(node.count, node.next);
        }
        if (tail.get(node.count) == node) {
            tail.put(node.count, node.prev);
        }
        if (node.prev != null) {
            node.prev.next = node.next;
        }
        if (node.next != null) {
            node.next.prev = node.prev;
        }
    }

    private void add(Node node) {
        node.count++;
        if (!head.containsKey(node.count)) {
            head.put(node.count, node);
        }
        if (!tail.containsKey(node.count)) {
            tail.put(node.count, node);
        }
        if (head.containsKey(node.count - 1)) {
            tail.get(node.count - 1).next = node;
            node.prev = tail.get(node.count - 1);
        }
        tail.put(node.count, node);
    }
}
