class StringPatternMatch {

    public static boolean match(String str, String pattern) {
        int n = str.length();
        int m = pattern.length();
        int i = 0;
        int j = 0;
        while (i < n && j < m) {
            char c = pattern.charAt(j);
            if (c == '@') {
                if (str.substring(i).equals(pattern.substring(j + 1))) {
                    return true;
                } else {
                    return false;
                }
            } else if (c == '#') {
                i++;
                j++;
            } else if (c == str.charAt(i)) {
                i++;
                j++;
            } else {
                return false;
            }
        }
        return (i == n && j == m);
    }

    public static void main(String[] args) {
        String a = "tt";
        String pattern = "@";
        System.out.println(match(a, pattern));
        // Output: true

        a = "ta";
        pattern = "t";
        System.out.println(match(a, pattern));
        // Output: false

        a = "ta";
        pattern = "t#";
        System.out.println(match(a, pattern));
        // Output: true
    }
}
