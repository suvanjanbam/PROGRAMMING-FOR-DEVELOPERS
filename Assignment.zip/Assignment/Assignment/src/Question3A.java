import java.util.Arrays;

public class Question3A {

        public static int minProductDifference(int[] arr) {
            Arrays.sort(arr);
            int minDiff = Integer.MAX_VALUE;
            for (int i = 0; i < arr.length / 2; i++) {
                int a = arr[i];
                int b = arr[arr.length - i - 1];
                int diff = Math.abs(a * b - (a + b));
                minDiff = Math.min(minDiff, diff);
            }
            return minDiff;
        }

        public static void main(String[] args) {
            int[] arr = {5, 2, 4, 11};
            System.out.println(minProductDifference(arr));
        }
    }


